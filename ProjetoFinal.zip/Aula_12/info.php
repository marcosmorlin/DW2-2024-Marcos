<?php

    phpinfo();
    
?>