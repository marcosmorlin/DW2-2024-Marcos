CREATE TABLE produtos 
(
  	id			serial NOT NULL,
	nome		character varying(350)	NOT NULL,
	urlfoto		character varying(350),	
	descricao	TEXT,
	CONSTRAINT produtos_pkey PRIMARY KEY (id)
)
WITH(
	OIDS = FALSE
)
TABLESPACE pg_default;

INSERT INTO produtos (nome, urlfoto, descricao)
	VALUES('Chinelo', 'https://havaianas.com.br/dw/image/v2/BDDJ_PRD/on/demandware.static/-/Sites-havaianas-master/default/dw978a6e76/product-images/4001280_0031_HAVAIANAS%TRADICIONAL_C.png','Este � o modelo que deu inicio a hist�ria de Havaianas e traduz a autenticidade da marca: para alguns � uma Havaianas com pre�o acess�vel: para muitos, representa um produto vintage que traz boas lembran�as.');
	
INSERT INTO produtos (nome, urlfoto, descricao)
	VALUES('Carregador de celular', 'https://imgs.pontof.com.br/1511673500/2xg.jpg','Os carregadores Turbo utilizam a tecnologia Quick Charge 2.0. Eles s�o capazes de carregar o seu aparelho at� 4 vezes mais r�pido. Esses carregadores trabalham com tens�es e intensidades de corrente mais elevadas, levando mais energia ao mesmo tempo para a bateria do seu aparelho');