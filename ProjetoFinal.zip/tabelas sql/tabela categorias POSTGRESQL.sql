CREATE TABLE categorias
(
  	id		serial NOT NULL,
	nome		character varying(350)	NOT NULL,
	CONSTRAINT categoria_pkey PRIMARY KEY (id)
)
WITH(
	OIDS = FALSE
)
TABLESPACE pg_default;

INSERT INTO categorias(nome)
	VALUES('Vestu�rio');

INSERT INTO categorias(nome)
	VALUES('Eletr�nicos');

INSERT INTO categorias(nome)
	VALUES('Brinquedos');